import numpy as np
import pickle


model1 = pickle.load(open('C:/Users/sabarishmanogaran/OneDrive - revature.com/Desktop/DS/Projectthree/model1.pkl','rb'))

input_data = (85,772,1955)

input_data_as_numpy_as_array = np.asarray(input_data)

#resahpe the array as we are predicting for one instance
input_data_reshaped = input_data_as_numpy_as_array.reshape(1,-1)

Prediction = model1.predict(input_data_reshaped)
print(Prediction)

if (Prediction[0] == 0):    
   print('Procurement Fraud does not happen')
else:
    print('Procurement Fraud happens')
