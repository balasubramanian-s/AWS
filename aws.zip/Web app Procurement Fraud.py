import numpy as np
import pickle
import streamlit as st

#loading the saved model
model1 = pickle.load(open('C:/Users/sabarishmanogaran/OneDrive - revature.com/Desktop/DS/Projectthree/model1.pkl','rb'))

#creating a function for predection
def Procurement_Preduiction(input_data):

    input_data_as_numpy_as_array = np.asarray(input_data)

    #resahpe the array as we are predicting for one instance
    input_data_reshaped = input_data_as_numpy_as_array.reshape(1,-1)

    Prediction = model1.predict(input_data_reshaped)
    print(Prediction)

    if (Prediction[0] == 0):    
       print('Procurement Fraud does not happen')
    else:
        print('Procurement Fraud happens')
        
        
def main():
    
    #giving a title
    st.title('Procuremnt Fruad Web App')
    
    #getting the input data from the user
    
    UnitPrice = st.text_input('Number of Unit Price')
    InflatedInvoice = st.text_input('InflatedInvoice')
    Employeescolludingwithsupplierswithhighercost = st.text_input('Employees colluding with suppliers with higher cost')
    
    #code for Prediction
    Fraudness = ''
    
    #creating a button for Prediction
    if st.button('Fraudness Test Result'):
        Fraudness = Procurement_Preduiction([UnitPrice, InflatedInvoice, Employeescolludingwithsupplierswithhighercost])
        
        st.success(Fraudness)
        
        
if __name__ == '__main__':
    main()          
        
            





    
    
    


    
       
    

    
    



    

     
    

    

     



    
    
    
    
    
